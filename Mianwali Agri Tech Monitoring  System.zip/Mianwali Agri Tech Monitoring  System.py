"""
EE-253: Data Structure and Algorithms - Assignment 1
Mianwali Agri-Tech Monitoring System
Student: Raheem Bakhsh
Date: November 13, 2025
"""

from datetime import datetime

# ================= Task 1: Sensor Packet =================

class SensorPacket:  
    def __init__(self, sensor_id, packet_type, data_payload):
        self.sensor_id = sensor_id
        self.packet_type = packet_type
        self.data_payload = data_payload
        self.timestamp = datetime.now()

    def __str__(self):
        time_str = self.timestamp.strftime('%Y-%m-%d %H:%M:%S')
        return f"[{time_str}] {self.packet_type} | Sensor: {self.sensor_id} | Data: {self.data_payload}"


# ================= Task 2: The Ingestion Hub (Deque) =================

class DequeNode:   
    def __init__(self, data):
        self.data = data
        self.next = None
        self.prev = None

class Deque:  
    def __init__(self):
        self.front = None
        self.rear = None
        self.size = 0

    def is_empty(self):
        if self.size == 0:
            return True
        else:
            return False

    def add_front(self, data):
        new_node = DequeNode(data)
        if self.is_empty():
            self.front = new_node
            self.rear = new_node
        else:
            new_node.next = self.front
            self.front.prev = new_node
            self.front = new_node
        self.size = self.size + 1

    def add_rear(self, data):
        new_node = DequeNode(data)
        if self.is_empty():
            self.front = new_node
            self.rear = new_node
        else:
            new_node.prev = self.rear
            self.rear.next = new_node
            self.rear = new_node
        self.size = self.size + 1

    def remove_front(self):
        if self.is_empty():
            return None
        
        data = self.front.data
        
        if self.front == self.rear:
            self.front = None
            self.rear = None
        else:
            self.front = self.front.next
            self.front.prev = None
        
        self.size = self.size - 1
        return data

# ================= Task 4: The Audit Trail (Stack) =================

class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        if self.is_empty() == True:
            return None
        return self.items.pop()

    def peek(self):
        if len(self.items) == 0:
            return None
        return self.items[-1]

    def is_empty(self):
        if len(self.items) == 0:
            return True
        else:
            return False

    def size(self):
        return len(self.items)

# ================= Task 2: DataIngestionHub =================

class DataIngestionHub:   
    def __init__(self):
        self.deque = Deque()
        self.audit_stack = Stack()

    def receive_packet(self, packet):
        if packet.packet_type == 'CRITICAL':
            self.deque.add_front(packet)
        elif packet.packet_type == 'ROUTINE':
            self.deque.add_rear(packet)
            
    def process_next_packet(self):
        packet = self.deque.remove_front()
        if packet != None:
            self.audit_stack.push(packet)
        return packet

    def review_last_N_packets(self, N):
        print("\n===== Last", N, "Processed Packets =====")
        temp = Stack()
        
        stack_size = self.audit_stack.size()
        if N < stack_size:
            count = N
        else:
            count = stack_size
        
        i = 1
        while i <= count:
            packet = self.audit_stack.pop()
            print(i, ".", packet)
            temp.push(packet)
            i = i + 1
        
        while temp.is_empty() == False:
            self.audit_stack.push(temp.pop())
        
        print("====================================\n")

    def is_empty(self):
        return self.deque.is_empty()


# ================= Task 3: Processed Log (Linked List) =================

class Node:   
    def __init__(self, data):
        self.data = data
        self.next = None

class SinglyLinkedList:   
    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0

    def is_empty(self):
        if self.head == None:
            return True
        else:
            return False

    def append(self, data):
        new_node = Node(data)
        
        if self.is_empty():
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node
        
        self.size = self.size + 1

    def traverse(self):
        temp = self.head
        while temp:
            yield temp.data
            temp = temp.next

    def get_size(self):
        return self.size


class ProcessedLog:   
    def __init__(self):
        self.log = SinglyLinkedList()

    def log_packet(self, packet):
        if packet != None:
            self.log.append(packet)

    def display_full_log(self):
        print("\n========= Complete Processed Log =========")
        
        if self.log.is_empty() == True:
            print("Log is empty")
        else:
            counter = 1
            for p in self.log.traverse():
                print(counter, ".", p)
                counter = counter + 1
        
        print("==========================================\n")


# ================= Task 5: Simulation =================

if __name__ == "__main__":
    print("\n=====================================")
    print(" Mianwali Agri-Tech Monitoring System ")
    print("=====================================\n")

    # Create hub and log
    hub = DataIngestionHub()
    log = ProcessedLog()

    print("Creating sensor packets...\n")

    # Create mix of ROUTINE and CRITICAL packets
    packets = []
    packets.append(SensorPacket("SOIL_01", "ROUTINE", "Moisture: 45%"))
    packets.append(SensorPacket("TEMP_02", "ROUTINE", "Temperature: 28°C"))
    packets.append(SensorPacket("FENCE_03", "CRITICAL", "BREACH DETECTED - Zone A"))
    packets.append(SensorPacket("SOIL_04", "ROUTINE", "Moisture: 52%"))
    packets.append(SensorPacket("LIVESTOCK_05", "ROUTINE", "Location: Field 3"))
    packets.append(SensorPacket("PUMP_06", "CRITICAL", "PUMP FAILURE - Field 2"))
    packets.append(SensorPacket("TEMP_07", "ROUTINE", "Temperature: 31°C"))
    packets.append(SensorPacket("SOIL_08", "ROUTINE", "Moisture: 48%"))
    packets.append(SensorPacket("FENCE_09", "CRITICAL", "BREACH DETECTED - Zone B"))
    packets.append(SensorPacket("TEMP_10", "ROUTINE", "Temperature: 29°C"))
    packets.append(SensorPacket("PUMP_11", "ROUTINE", "Status: Normal"))
    packets.append(SensorPacket("LIVESTOCK_12", "CRITICAL", "OUTSIDE GEOFENCE - Animal 42"))
    packets.append(SensorPacket("SOIL_13", "ROUTINE", "Moisture: 51%"))
    packets.append(SensorPacket("TEMP_14", "ROUTINE", "Temperature: 30°C"))
    packets.append(SensorPacket("FENCE_15", "CRITICAL", "BREACH DETECTED - Zone C"))

    print("Receiving packets in mixed order...\n")
    
    # Add packets to hub
    for p in packets:
        hub.receive_packet(p)
        print("Received:", p.packet_type, "-", p.sensor_id)

    print("\nProcessing all packets...\n")
    
    # Process all packets
    while hub.is_empty() == False:
        packet = hub.process_next_packet()
        log.log_packet(packet)
        print("Processed:", packet.sensor_id)

    print("\nAll packets processed.\n")
    
    # Display complete log
    log.display_full_log()
    
    # Review last 5 packets
    hub.review_last_N_packets(5)

    print("Simulation Complete\n")
    print("Total packets received:", len(packets))
    print("Total packets processed:", log.log.get_size())
    print()