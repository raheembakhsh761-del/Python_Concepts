def multiply_number(num1, num2):  # function to multiply two numbers
    product = num1 * num2  # multiply numbers
    return product  # return result


def main():  # main function
    num1 = float(input("Enter first number = "))  # input first number
    num2 = float(input("Enter second number = "))  # input second number
    product_number = multiply_number(num1, num2)  # call function
    print("The product of numbers is:", product_number)  # print result


if __name__ == '__main__':  # program entry point
    main()  # call main function
