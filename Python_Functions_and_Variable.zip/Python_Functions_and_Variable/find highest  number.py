# Function to find the highest number in the list by swap method
def find_highest(num_list):
    num2 = num_list[:]  # make a copy of the list
    for i in range(len(num2)):  # outer loop for passes
        for j in range(len(num2) - 1):  # inner loop to compare elements
            if num2[j] < num2[j + 1]:  # check if current is smaller than next
                temp1 = num2[j]  # swap numbers
                num2[j] = num2[j + 1]
                num2[j + 1] = temp1
    return num2[0]  # first element is highest after sorting


price_list = [85, 92, 78, 90, 88, 12, 45, 67, 89]  # given list
result = find_highest(price_list)  # function call
print("The highest number is =", result)  # output result
