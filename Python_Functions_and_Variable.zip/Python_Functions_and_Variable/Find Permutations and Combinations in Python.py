def find_permutations(n, r):  # function to find permutations
    fact_n = 1  # store factorial of n
    fact_nr = 1  # store factorial of (n-r)
    temp_n = n  # copy n
    temp_nr = n - r  # copy (n-r)
    while temp_n > 0:  # factorial of n
        fact_n *= temp_n
        temp_n -= 1
    while temp_nr > 0:  # factorial of (n-r)
        fact_nr *= temp_nr
        temp_nr -= 1
    return fact_n // fact_nr  # formula P(n,r) = n! / (n-r)!


def find_combinations(n, r):  # function to find combinations
    fact_r = 1  # store factorial of r
    temp_r = r
    while temp_r > 0:  # factorial of r
        fact_r *= temp_r
        temp_r -= 1
    return find_permutations(n, r) // fact_r  # formula C(n,r) = P(n,r) / r!


r = int(input("Enter the value of r: "))  # input r
n = int(input("Enter the number of objects n: "))  # input n
print("Permutations P(n,r) =", find_permutations(n, r))  # print permutations
print("Combinations C(n,r) =", find_combinations(n, r))  # print combinations
