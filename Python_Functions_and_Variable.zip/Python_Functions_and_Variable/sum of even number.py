sum_even = 0  # store sum of even numbers
count = 0     # counter for 10 numbers

print("Enter 10 numbers:")  # display message

while count < 10:  # loop runs 10 times
    num = int(input("Enter number: "))  # take number from user
    if num % 2 == 0:  # check even number
        sum_even = sum_even + num  # add even number to sum
    count = count + 1  # increase counter

print("Sum of even numbers =", sum_even)  # print final sum
