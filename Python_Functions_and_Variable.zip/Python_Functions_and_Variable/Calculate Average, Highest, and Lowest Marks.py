def average_mark(marks):  # function to calculate average
    return sum(marks) / len(marks)  # formula for average


def highest_lowest(num_list):  # function to find highest & lowest
    num2 = num_list[:]  # copy list into another variable
    for i in range(len(num2)):  # outer loop for passes
        for j in range(len(num2) - 1):  # inner loop for comparisons
            if num2[j] < num2[j + 1]:  # if current < next, then swap
                temp1 = num2[j]  # swapping
                num2[j] = num2[j + 1]
                num2[j + 1] = temp1
    return num2[0], num2[len(num2) - 1]  # highest = first, lowest = last


n = int(input("Enter number of students: "))  # input number of students
marks = []  # empty list for marks

for i in range(n):  # loop to take marks input
    m = int(input("Enter marks of student {}: ".format(i + 1)))
    marks.append(m)  # add marks to list

average = average_mark(marks)  # function call for average
high, low = highest_lowest(marks)  # function call for high & low

print("The average marks is =", average)  # print average
print("Highest marks:", high)  # print highest marks
print("Lowest marks:", low)  # print lowest marks

# control flow
if average >= 50:  # check condition for class performance
    print("Class performed Above Average")  # output if >= 50
else:
    print("Class performed Below Average")  # output if < 50
