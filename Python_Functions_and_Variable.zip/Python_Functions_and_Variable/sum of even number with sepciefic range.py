def sum_of_number(start, end):  # function to find sum of even numbers
    total = 0  # initialize sum
    for i in range(start, end + 1):  # loop from start to end
        if i % 2 == 0:  # check if number is even
            total = total + i  # add even number to total
    return total  # return final sum


start = int(input("Enter your Roll No = "))  # input start value
end = int(input("Enter your Roll No + 2 * Roll No = "))  # input end value

result = sum_of_number(start, end)  # call function
print("Sum of all even numbers from start to end =", result)  # output
