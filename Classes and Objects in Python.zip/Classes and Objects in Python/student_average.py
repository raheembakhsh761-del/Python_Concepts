class Student:
    def __init__(self, name, marks):
        self.name = name
        self.marks = marks

    def average(self):
        return sum(self.marks) / len(self.marks)


name = input("Enter student name: ")
marks = []

for i in range(3):
    mark = float(input(f"Enter mark for subject {i+1}: "))
    marks.append(mark)

student1 = Student(name, marks)

print("\nStudent Name:", student1.name)
print("Average Marks:", student1.average())
