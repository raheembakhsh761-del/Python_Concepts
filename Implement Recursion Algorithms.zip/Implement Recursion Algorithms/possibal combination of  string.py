#RAHEEM BAKHSH
#NUM-BSEE-2023-10
def re(set2, k):
    if k == 0:
        return [[]]
    first = set2[0]
    rest = re(set2[1:], k - 1)
    final = []
    for i in rest:
        new = i.copy()
        new.append(first)
        final.append(new)
    return rest + final

name = "ABC"
set1 = list(name)
k = len(set1)
subsets = re(set1, k)

subsets = subsets[1:]                  
subsets = sorted(subsets, key=lambda x: (len(x), x)) #help this function from google  

for s in subsets:
    print(s)