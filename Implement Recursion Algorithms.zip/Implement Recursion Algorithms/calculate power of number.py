def power(a, b):

    if b == 0:
        return 1
    
    return a * power(a, b - 1)
base= 2
exponent=5
result=power(base, exponent)  
print("Base     :", base)
print("Exponent :", exponent)
print("Result   :", result)