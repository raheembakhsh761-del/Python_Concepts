# Queue Class Definition
class Queue:
    def __init__(self, capacity):
        self.capacity = capacity
        self.items = []

    def length(self):
        return len(self.items)

    def is_empty(self):
        return len(self.items) == 0

    def is_full(self):
        return len(self.items) == self.capacity

    def front(self):
        if self.is_empty():
            return None
        return self.items[0]
    # Enqueue Method
    def enqueue(self, item):
        if self.is_full():
            raise IndexError("Queue is full")
        self.items.append(item)
    # Task (a): Dequeue Method
    def dequeue(self):
        if self.is_empty():
            raise IndexError("Queue is empty")
        return self.items.pop(0)   # remove and return first element

    # Resize Method
    def resize(self, new_size):
        if new_size < self.length():
            self.items = self.items[:new_size]
        self.capacity = new_size

    # Task (b): Print Method
    def print(self):
        if self.is_empty():
            print("Queue is empty.")
        else:
            print("Queue elements are:", end=" ")
            for item in self.items:
                print(item, end=" ")
            print()     
    # Main Portion
if __name__ == "__main__":
    # Create a queue of capacity 5
    q = Queue(5)
    q.enqueue(10)
    q.enqueue(20)
    q.enqueue(30)

    q.print()
    removed = q.dequeue()
    print("Dequeued element:", removed)

    # Print queue after dequeue
    q.print()

    # Check front element
    print("Front element:", q.front())

    # Check length of queue
    print("Length of queue:", q.length())
    # Resize the queue
    q.resize(3)
    print("Queue resized to capacity 3")
    q.enqueue(50)
    q.print()