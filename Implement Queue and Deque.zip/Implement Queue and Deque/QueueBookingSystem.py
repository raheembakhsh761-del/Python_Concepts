from collections import deque

class TicketSystem:
    def __init__(self):
        self.q = deque()

    def add_front(self, t):
        self.q.appendleft(t)
        print(f"Booked '{t}' from FRONT")

    def add_back(self, t):
        self.q.append(t)
        print(f"Booked '{t}' from BACK")

    def del_front(self):
        if self.q:
            print(f"Canceled '{self.q.popleft()}' from FRONT")
        else:
            print("No ticket to cancel FRONT")

    def del_back(self):
        if self.q:
            print(f"Canceled '{self.q.pop()}' from BACK")
        else:
            print("No ticket to cancel BACK")

    def total(self):
        return len(self.q)
    
    # New function to show all tickets
    def show_all(self):
        if self.q:
            print("All Tickets in Queue:", list(self.q))
        else:
            print("No tickets in the system")


def main():
    s = TicketSystem()
    while True:
        c = input("Enter 1 for (book), -1 for (cancel), exit: ")
        if c == 'exit':
            break
        elif c == '1':
            side = input("F/B: ").upper()
            t = input("Ticket name: ")
            if side == 'F':
                s.add_front(t)
                s.show_all()
            else:
                s.add_back(t)
                s.show_all()
        elif c == '-1':
            side = input("F/B: ").upper()
            if side == 'F':
                s.del_front()
                s.show_all()
            else:
                s.del_back()
                s.show_all()
        print("Total Tickets:", s.total())


if __name__ == "__main__":
    main()
