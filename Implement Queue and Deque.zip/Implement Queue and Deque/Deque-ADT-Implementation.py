
class Deque:
    def __init__(self, capacity):
        self.capacity = capacity             # Maximum size of deque
        self.arr = [None] * capacity         # Circular array
        self.front = -1                      # Points to front element
        self.rear = -1                       # Points to rear element
        self.size = 0                        # Current number of elements

    # Check if deque is empty
    def is_empty(self):
        return self.size == 0

    # Check if deque is full
    def is_full(self):
        return self.size == self.capacity

    # Insert element at front
    def insert_front(self, value):
        if self.is_full():
            print("Deque is FULL. Cannot insert at front.")
            return False
        if self.front == -1:                 # If deque is empty
            self.front = 0
            self.rear = 0
        else:
            self.front = (self.front - 1 + self.capacity) % self.capacity
        self.arr[self.front] = value
        self.size += 1
        return True

    # Delete element from front
    def delete_front(self):
        if self.is_empty():
            print("Deque is EMPTY. Cannot delete from front.")
            return False
        if self.front == self.rear:          # Only one element
            self.front = -1
            self.rear = -1
        else:
            self.front = (self.front + 1) % self.capacity
        self.size -= 1
        return True

    # Task 2(a) Insert element at the back
    def insert_back(self, value):
        if self.is_full():
            print("Deque is FULL. Cannot insert at back.")
            return False
        if self.front == -1:                 # If deque is empty
            self.front = 0
            self.rear = 0
        else:
            self.rear = (self.rear + 1) % self.capacity
        self.arr[self.rear] = value
        self.size += 1
        return True

    #  Task 2(b) Delete element from the back
    def delete_back(self):
        if self.is_empty():
            print("Deque is EMPTY. Cannot delete from back.")
            return False
        if self.front == self.rear:          # Only one element
            self.front = -1
            self.rear = -1
        else:
            self.rear = (self.rear - 1 + self.capacity) % self.capacity
        self.size -= 1
        return True

    #  Print all elements of the deque
    def print_deque(self):
        if self.is_empty():
            print("Deque is empty.")
            return
        print("Deque elements are:", end=" ")
        i = self.front
        while True:
            print(self.arr[i], end=" ")
            if i == self.rear:
                break
            i = (i + 1) % self.capacity
        print()


#  Main Portion
if __name__ == "__main__":
    dq = Deque(5)            
    dq.insert_back(10)
    dq.insert_back(20)
    dq.insert_front(5)
    dq.insert_back(30)
    dq.print_deque()
    print("delete fronth element ")
    dq.delete_front()
    dq.print_deque()
    print("delete fronth element ")
    dq.delete_back()
    dq.print_deque()
