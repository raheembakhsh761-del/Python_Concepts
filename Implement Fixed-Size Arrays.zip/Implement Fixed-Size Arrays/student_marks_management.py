# Initialize an array of 10 elements with -1 (means empty)
marks = [-1] * 10

# Function to display all marks (except -1)
def display_marks():
    arr3 = []  # temporary list to store valid marks
    for element in marks:
        if element != -1:  # skip empty (-1) entries
            arr3.append(element)
    print("Display all marks:", arr3)


# Function to insert a mark at a specific position
def insert_mark():  # <-- function to insert mark
    position = int(input("Enter position where you want to enter the marks (0–9): "))
    # Check for valid position
    if position < 0 or position >= 10:
        print("Invalid position! Position must be 0–9.")
        return

    # Check if position already filled
    if marks[position] != -1:
        print("Already entered the mark of student.")
        return

    # Take mark input
    mark = int(input("Enter mark between (0–100): "))

    # Validate and store mark
    if 0 <= mark <= 100:
        marks[position] = mark
        print("Mark entered successfully!")
        display_marks()  # show updated marks automatically
    else:
        print("Invalid mark! Must be between 0–100.")


# Function to delete a mark
def delete_mark():
    position = int(input("Enter position (0–9) for delete: "))
    # Validate position
    if position < 0 or position >= 10:
        print("Invalid position!")
    elif marks[position] == -1:  # check if no mark present
        print("No mark exists at this position.")
    else:
        marks[position] = -1  # remove mark
        print("Mark is deleted.")
        display_marks()  # show all marks after deletion


# Function to search for a specific mark
def search_mark():
    mark1 = int(input("Enter mark to search for: "))
    found = False
    for index in range(len(marks)):
        if mark1 == marks[index]:  # if found
            print(f"Mark is found at index = {index}")
            found = True
            break
    if not found:
        print("Mark is not found")


# Function to update an existing mark
def update_mark():
    position = int(input("Enter position (0–9) to update: "))
    if position < 0 or position >= 10:
        print("Invalid position!")
        return
    if marks[position] == -1:
        print("No existing mark at this position.")
        return
    new_mark = int(input("Enter new mark (0–100): "))
    if 0 <= new_mark <= 100:
        marks[position] = new_mark
        print("Mark updated successfully!")
    else:
        print("Invalid mark! Must be between 0–100.")


# Function to find highest and lowest marks
def stats():
    arr2 = []  # store only valid marks
    for element in marks:
        if element != -1:
            arr2.append(element)

    # Find max and min if list not empty
    if arr2:
        maximum = max(arr2)
        minimum = min(arr2)
    else:
        maximum = None
        minimum = None

    # Show details
    print("Original array:", marks)
    print("Filtered array:", arr2)
    print("Maximum value:", maximum)
    print("Minimum value:", minimum)


# Main program menu (loop until user exits)
while True:
    print("\n=== Main Menu ===")
    print("1. Display all marks")
    print("2. Insert a mark at a specific position")
    print("3. Delete a mark")
    print("4. Search for a specific mark")
    print("5. Update an existing mark")
    print("6. Find highest and lowest marks")
    print("7. Exit the program")

    choice = input("Enter your choice (1–7): ")

    # Menu control using if-elif
    if choice == '1':
        display_marks()
    elif choice == '2':
        insert_mark()
    elif choice == '3':
        delete_mark()
    elif choice == '4':
        search_mark()
    elif choice == '5':
        update_mark()
    elif choice == '6':
        stats()
    elif choice == '7':
        print("Exiting program...")
        break
    else:
        print("Invalid choice! Please enter a number between 1–7.")
