from array import *  # import all functions from array module

def sorted_array(arr):  # function to return sorted array
    return sorted(arr)

arr = []  # create empty array
n = int(input("Enter the number of elements: "))  # input total elements

# input array elements one by one
for i in range(n):
    element = int(input(f"Enter number at index {i}: "))
    arr.append(element)  # add element to array

print("Array elements:", arr)  # display entered array

arr.reverse()  # reverse the array
print("Reversed array:", arr)  # display reversed array

sorted_arr = sorted_array(arr)  # get sorted array
print("Sorted array:", sorted_arr)  # display sorted array
