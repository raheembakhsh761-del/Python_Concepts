arr = []  # create empty array
n = int(input("Enter the number of elements: "))  # take number of elements

# input array elements
for i in range(n):
    element = int(input(f"Enter number at index {i}: "))
    arr.append(element)  # add element to array

print("Array elements:", arr)  # display all elements

total = 0  # initialize sum
for i in range(n):
    total += arr[i]  # add each element to sum

print(f"Sum of numbers = {total}")  # print total sum

average = total / n  # calculate average
print(f"Average of numbers = {average}")  # print average
