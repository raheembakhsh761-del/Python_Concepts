num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))

if num1 > num2:
    print("The first number is greater than the second number.")
elif num1 < num2:
    print("The second number is greater than the first number.")
else:
    print("Both numbers are equal.")
