def calculate_perimeter(length, width):
    perimeter = 2 * (length + width)
    return perimeter

length = float(input("Enter the length: "))
width = float(input("Enter the width: "))

result = calculate_perimeter(length, width)
print(f"The perimeter is: {result}")
