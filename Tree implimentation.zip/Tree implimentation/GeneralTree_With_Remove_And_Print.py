# Tree Node class
class TreeNode:
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.children = []


# General Tree class
class GeneralTree:
    def __init__(self, rootKey, rootValue):
        self.root = TreeNode(rootKey, rootValue)

    # Add new node under parent
    def add(self, key, value, parentKey):
        parent = self.find(parentKey)
        if parent:
            parent.children.append(TreeNode(key, value))
        else:
            print("Parent not found!")

    # Find a node by key
    def find(self, targetKey):

        def recusion_search(node):
            if node.key == targetKey:
                return node
            for child in node.children:
                result = recusion_search(child)
                if result:
                    return result
            return None

        return recusion_search(self.root)

    # Find parent of given node
    def findParent(self, targetKey):

        def search(node):
            for child in node.children:
                if child.key == targetKey:
                    return node
                result = search(child)
                if result:
                    return result
            return None

        return search(self.root)

    # Remove a node
    def remove(self, targetKey):
        if self.root.key == targetKey:
            print("Root cannot be removed!")
            return

        parent = self.findParent(targetKey)

        if parent is None:
            print("Node not found!")
            return

        # delete from parent's child list
        for i in range(len(parent.children)):
            if parent.children[i].key == targetKey:
                parent.children.pop(i)
                print("Node removed:", targetKey)
                return

    # Print tree
    def printTreeAsString(self):

        def show(node, level):
            print("  " * level + node.key, "->", node.value)
            for child in node.children:
                show(child, level + 1)

        show(self.root, 0)
        print("-------------------------")


tree = GeneralTree("A", "Root")
tree.add("B", "Level 1 Child", "A")
tree.add("C", "Level 1 Child", "A")
tree.add("D", "Level 2 Child of B", "B")
tree.add("E", "Level 2 Child of C", "C")
tree.add("F", "Level 3 Child of D", "D")
tree.add("G", "Level 3 Child of E", "E")

print("Initial Tree:")
tree.printTreeAsString()
testKeys = ["E", "B", "A", "Z", "F"]

for key in testKeys:
    print("For  remove by key:", key)
    tree.remove(key)
    tree.printTreeAsString()
