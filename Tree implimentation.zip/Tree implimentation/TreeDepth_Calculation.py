# Tree Node class
class TreeNode:
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.children = []
# General Tree class
class GeneralTree:
    def __init__(self, rootKey, rootValue):
        self.root = TreeNode(rootKey, rootValue)

    # Add a new node under parent
    def add(self, key, value, parentKey):
        parent = self.find(parentKey)
        if parent:
            parent.children.append(TreeNode(key, value))
        else:
            print("Parent not found!")

    # Find a node by its key
    def find(self, targetKey):

        def search(node):
            if node.key == targetKey:
                return node
            for child in node.children:
                result = search(child)
                if result:
                    return result
            return None

        return search(self.root)

    # Find parent of a given node
    def findParent(self, targetKey):

        def search(node):
            for child in node.children:
                if child.key == targetKey:
                    return node
                result = search(child)
                if result:
                    return result
            return None

        return search(self.root)

    # Calculate depth of a given node
    def CalculateDepth(self, node_ptr):
        depth = 0
        current = node_ptr

        while current != self.root:
            parent = self.findParent(current.key)
            if parent is None:
                break
            depth += 1
            current = parent

        return depth

    # Print tree function
    def printTreeAsString(self):

        def show(node, level):
            print("  " * level + node.key, "->", node.value)
            for child in node.children:
                show(child, level + 1)

        show(self.root, 0)
        print("-------------------------")


# Testing the tree
tree = GeneralTree("A", "Root")

tree.add("B", "Level 1 Child", "A")
tree.add("C", "Level 1 Child", "A")
tree.add("D", "Level 2 Child of B", "B")
tree.add("E", "Level 2 Child of C", "C")
tree.add("F", "Level 3 Child of D", "D")
tree.add("G", "Level 3 Child of E", "E")

print("Initial Tree:")
tree.printTreeAsString()

nodeF = tree.find("F")
print("Depth of F:", tree.CalculateDepth(nodeF))
nodeB = tree.find("B")
print("Depth of B:", tree.CalculateDepth(nodeB))

nodeA = tree.find("A")
print("Depth of A:", tree.CalculateDepth(nodeA))
