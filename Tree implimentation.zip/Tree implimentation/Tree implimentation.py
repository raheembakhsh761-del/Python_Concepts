# Class for a Tree Node
class TreeNode:
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.children = []

# Class for the General Tree
class GeneralTree:
    def __init__(self, rootKey, rootValue):
        self.root = TreeNode(rootKey, rootValue)

    # Add a node under a specific parent
    def add(self, key, value, parentKey):
        parent_node = self.find(parentKey)
        if parent_node:
            parent_node.children.append(TreeNode(key, value))
        else:
            print(f"Parent with key '{parentKey}' not found.")

    def find(self, targetKey):
       

        def recursion_find(node):
            if node.key == targetKey:
                return node     # found the match

            # search in children
            for child in node.children:
                found = recursion_find(child)
                if found:
                    return found

            return None  

        return recursion_find(self.root)

tree = GeneralTree("A", "Root")

# Add nodes
tree.add("B", "Level 1 Child 1", "A")
tree.add("C", "Level 1 Child 2", "A")
tree.add("D", "Level 2 Child of B", "B")
tree.add("E", "Level 2 Child of C", "C")
tree.add("F", "Level 3 Child of D", "D")
tree.add("G", "Level 3 Child of E", "E")

test_keys = ["A", "B", "E", "Z","F","G"]  

for key in test_keys:
    node = tree.find(key)
    if node:
        print(f"Node found -> Key: {node.key}, Value: {node.value}")
    else:
        print(f"Node with key '{key}' not found.")
