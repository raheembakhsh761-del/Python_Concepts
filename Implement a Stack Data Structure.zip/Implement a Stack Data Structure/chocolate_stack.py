# Filename: chocolate_stack.py

class ChocolateStack:
    def __init__(self):
        self.data = []

    def is_empty(self):
        return len(self.data) == 0

    def chocolates_available(self, chocolates):
        """Add a box of chocolates on top of the stack."""
        self.data.append(chocolates)
        print(f"A box of {chocolates} chocolates added.")
        print(f"Current Stack : {self.data}\n")

    def chocolates_sold(self, amount):
        """Sell chocolates from the top box."""
        if self.is_empty():
            print("No boxes available to sell from.\n")
            return

        print(f"Selling {amount} chocolates...")
        while amount > 0 and not self.is_empty():
            top_box = self.data[-1]  # Top box
            if top_box > amount:
                # Reduce chocolates from top box
                self.data[-1] -= amount
                print(f"{amount} chocolates sold from top box.")
                print(f"Remaining chocolates in top box: {self.data[-1]}\n")
                amount = 0
            else:
                # Sell all chocolates from top box
                amount -= top_box
                print(f"All {top_box} chocolates sold from one box. Box removed.")
                self.data.pop()

        if self.is_empty():
            print("All boxes are empty now.\n")
        else:
            print(f"Remaining Stack : {self.data}\n")

    def display(self):
        if self.is_empty():
            print("No boxes in stack.")
        else:
            print(f"Current Stack : {self.data}")


# ---------- main code ----------
shop_stack = ChocolateStack()

# Add boxes
shop_stack.chocolates_available(30)
shop_stack.chocolates_available(20)
shop_stack.chocolates_available(10)

# Sell some chocolates
shop_stack.chocolates_sold(5)

# Sell more chocolates
shop_stack.chocolates_sold(15)

# Add new box
shop_stack.chocolates_available(25)

# Sell large number of chocolates
shop_stack.chocolates_sold(50)

# Final Stack Display
shop_stack.display()
