# Filename: number_game_stack.py

class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        if not self.is_empty():
            return self.items.pop()
        return None

    def is_empty(self):
        return len(self.items) == 0

    def __str__(self):
        return str(self.items)


def play_game(A_list, B_list):
    result_stack = Stack()
    while A_list and B_list:
        a_num = A_list[0]
        b_num = B_list[-1]

        if a_num > b_num:
            result = 1
            B_list.pop()
        elif a_num < b_num:
            result = 2
            A_list.pop(0)
        else:
            result = 0
            A_list.pop(0)
            B_list.pop()

        result_stack.push(result)

    return result_stack


# Initial lists
A = [2, 4, 5, 6, 7, 8, 9]
B = [2, 4, 5, 6, 7, 8, 9]

# Play the game
result = play_game(A, B)

# Display final results
print("Final result stack:", result)
