# Filename: reverse_string_stack.py

class Stack:
    def __init__(self):
        self.data = []

    def push(self, item):
        self.data.append(item)

    def pop(self):
        if not self.is_empty():
            return self.data.pop()

    def is_empty(self):
        return len(self.data) == 0


# Create stack object
s = Stack()

# Input from user
string = input("Enter a string: ")

# Push all characters into stack
for ch in string:
    s.push(ch)

# Pop characters to form reversed string
reversed_string = ""
while not s.is_empty():
    reversed_string += s.pop()

# Display results
print("Original String:", string)
print("Reversed String:", reversed_string)
