import ctypes

class DynamicArray:
    """A dynamic array class similar to a simplified Python list."""

    def __init__(self):
        """Create an empty array."""
        self.n = 0  # Count of actual elements
        self.capacity = 1  # Default capacity
        self.A = self.make_array(self.capacity)

    def compute_len(self):
        """Return number of elements stored in the array."""
        return self.n

    def get_data_at_index(self, k):
        """Return element at index k."""
        if not 0 <= k < self.n:
            raise IndexError("Invalid index")
        return self.A[k]

    def append(self, obj):
        """Add object to the end of the array."""
        if self.n == self.capacity:
            self.resize(2 * self.capacity)  # Double the capacity
        self.A[self.n] = obj
        self.n += 1

    def resize(self, c):
        """Resize internal array to capacity c."""
        B = self.make_array(c)
        for k in range(self.n):
            B[k] = self.A[k]
        self.A = B
        self.capacity = c

    def make_array(self, c):
        """Return a new array with capacity c."""
        return (c * ctypes.py_object)()

    # i. Method to display all elements of the dynamic array
    def display(self):
        print("Dynamic Array Contents:", end=" ")
        for i in range(self.n):
            print(self.A[i], end=" ")
        print()

    # ii. Method to return a new DynamicArray with unique elements
    def unique_elements(self):
        unique_arr = DynamicArray()
        seen = set()
        for i in range(self.n):
            val = self.A[i]
            if val not in seen:
                unique_arr.append(val)
                seen.add(val)
        return unique_arr


if __name__ == "__main__":
    dynamic_arr = DynamicArray()
    size = int(input("Enter number of elements: "))

    # Input elements into dynamic array
    for i in range(size):
        val = input(f"Enter element {i + 1}: ")
        dynamic_arr.append(val)

    print("\nOriginal Array:")
    dynamic_arr.display()

    # Get array with unique elements
    unique_arr = dynamic_arr.unique_elements()
    print("Unique Elements Array:")
    unique_arr.display()
