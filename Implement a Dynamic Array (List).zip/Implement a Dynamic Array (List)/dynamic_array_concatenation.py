# Filename: dynamic_array_concatenation.py

import ctypes

class DynamicArray:
    """A dynamic array class similar to a simplified Python list."""

    def __init__(self):
        """Create an empty array."""
        self.n = 0  # Number of elements
        self.capacity = 1  # Default capacity
        self.A = self.make_array(self.capacity)  # Low-level array

    def __len__(self):
        """Return number of elements stored in the array."""
        return self.n

    def make_array(self, new_cap):
        """Return a new array with capacity new_cap."""
        return (new_cap * ctypes.py_object)()

    def resize(self, new_cap):
        """Resize internal array to new_cap."""
        B = self.make_array(new_cap)
        for i in range(self.n):
            B[i] = self.A[i]
        self.A = B
        self.capacity = new_cap

    def insert_at(self, index, value):
        """Insert value at specific index."""
        if index < 0 or index > self.n:
            raise IndexError("Invalid index!")

        if self.n == self.capacity:
            self.resize(2 * self.capacity)

        # Shift elements to the right
        for i in range(self.n, index, -1):
            self.A[i] = self.A[i - 1]

        self.A[index] = value
        self.n += 1

    def display(self):
        """Display all elements of the array."""
        print("Array Elements:", end=" ")
        for i in range(self.n):
            print(self.A[i], end=" ")
        print()

    def concatenate(self, other):
        """Concatenate two DynamicArrays and return a new DynamicArray."""
        new_array = DynamicArray()
        new_array.resize(self.n + other.n)

        # Copy elements from first array
        for i in range(self.n):
            new_array.A[i] = self.A[i]

        # Copy elements from second array
        for j in range(other.n):
            new_array.A[self.n + j] = other.A[j]

        # Update total size
        new_array.n = self.n + other.n
        return new_array


# --- Main Program ---
arr1 = DynamicArray()
arr1.insert_at(0, 10)
arr1.insert_at(1, 20)
arr1.insert_at(2, 30)
arr1.insert_at(3, 5)
arr1.insert_at(4, 89)

arr2 = DynamicArray()
arr2.insert_at(0, 40)
arr2.insert_at(1, 50)
arr2.insert_at(2, 60)
arr2.insert_at(3, 80)
arr2.insert_at(4, 90)

print("Array 1:")
arr1.display()

print("Array 2:")
arr2.display()

# Concatenate both arrays
arr3 = arr1.concatenate(arr2)
print("Concatenated Array:")
arr3.display()
