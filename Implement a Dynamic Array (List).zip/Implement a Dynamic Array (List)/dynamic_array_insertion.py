# Filename: dynamic_array_insertion.py

import ctypes

class DynamicArray:
    """A dynamic array class similar to a simplified Python list."""

    def __init__(self):
        """Create an empty array."""
        self.n = 0  # Count of actual elements
        self.capacity = 1  # Default capacity
        self.A = self.make_array(self.capacity)  # Create low-level array

    def __len__(self):
        """Return number of elements stored in the array."""
        return self.n

    def make_array(self, new_cap):
        """Return a new array with new_cap capacity."""
        return (new_cap * ctypes.py_object)()

    def resize(self, new_cap):
        """Resize internal array to capacity new_cap."""
        B = self.make_array(new_cap)
        for i in range(self.n):
            B[i] = self.A[i]
        self.A = B
        self.capacity = new_cap

    def insert_at(self, index, value):
        """Insert value at a specific index."""
        if index < 0 or index > self.n:
            raise IndexError("Invalid index!")

        # Resize if array is full
        if self.n == self.capacity:
            self.resize(2 * self.capacity)

        # Shift elements to the right
        for i in range(self.n, index, -1):
            self.A[i] = self.A[i - 1]

        # Insert the new element
        self.A[index] = value
        self.n += 1

        # Display array contents and capacity
        self.display()
        print(f"Current Capacity: {self.capacity}\n")

    def display(self):
        """Display the current array elements."""
        print("Array Elements:", end=" ")
        for i in range(self.n):
            print(self.A[i], end=" ")
        print()


# Test the DynamicArray class
if __name__ == "__main__":
    arr = DynamicArray()
    arr.insert_at(0, 10)
    arr.insert_at(1, 20)
    arr.insert_at(2, 30)
    arr.insert_at(1, 15)
    arr.insert_at(0, 5)
    arr.insert_at(0, 6)
    arr.insert_at(0, 9)
    arr.insert_at(0, 13)
    arr.insert_at(0, 7)
